<?php
namespace CTB\Core;
use CTB\Api\PostCreator;
class Publisher {
    public function __construct( private PostCreator $creator, private Options $options, private Logger $logger ) {}
    public function register_hooks(): void {
        add_action( 'transition_post_status', [ $this, 'maybe_crosspost' ], 10, 3 );
    }
    public function maybe_crosspost( string $new_status, string $old_status, \WP_Post $post ): void {
        if ( 'publish' !== $new_status || 'publish' === $old_status ) return;
        if ( ! $this->options->get( 'auto_crosspost', 1 ) ) return;
        $enabled = (array) $this->options->get( 'enabled_post_types', [ 'post' ] );
        if ( ! in_array( $post->post_type, $enabled, true ) ) {
            $this->logger->debug( 'Skipped: post type not enabled.', [ 'post_id' => $post->ID, 'post_type' => $post->post_type, 'enabled' => $enabled ] );
            return;
        }
        if ( get_post_meta( $post->ID, '_ctb_skip_crosspost', true ) ) { $this->logger->debug( 'Skipped: manual skip flag.', [ 'post_id' => $post->ID ] ); return; }
        if ( get_post_meta( $post->ID, '_ctb_bluesky_uri', true ) )     { $this->logger->debug( 'Skipped: already crossposted.', [ 'post_id' => $post->ID ] ); return; }
        $this->logger->info( 'Starting crosspost.', [ 'post_id' => $post->ID, 'post_type' => $post->post_type ] );
        $result = $this->creator->create_from_post( $post );
        if ( is_wp_error( $result ) ) {
            update_post_meta( $post->ID, '_ctb_last_error', $result->get_error_message() );
            $this->logger->error( 'Crosspost failed: ' . $result->get_error_message(), [ 'post_id' => $post->ID ] );
            return;
        }
        update_post_meta( $post->ID, '_ctb_bluesky_uri', $result['uri'] ?? '' );
        update_post_meta( $post->ID, '_ctb_bluesky_cid', $result['cid'] ?? '' );
        delete_post_meta( $post->ID, '_ctb_last_error' );
        $this->logger->info( 'Crosspost succeeded.', [ 'post_id' => $post->ID, 'uri' => $result['uri'] ?? '' ] );
    }
}
